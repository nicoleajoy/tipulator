//
//  ViewController.swift
//  Prework
//
//  Created by Nicole Ajoy on 8/22/21.
//

import UIKit;
import SwiftUI;

class ViewController: UIViewController {
    
    @IBOutlet weak var billAmountTextField: UITextField!
    @IBOutlet weak var tipAmountLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var tipPercentageLabel: UILabel!
    @IBOutlet weak var tipSlider: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        billAmountTextField.attributedPlaceholder = NSAttributedString(string:"0.00", attributes: [NSAttributedString.Key.foregroundColor: UIColor.white]);
        billAmountTextField.addTarget(self, action: #selector(ViewController.textFieldDidChange(_:)), for: .editingChanged);
        
        RoundedRectangle(cornerRadius: 25)
            .fill(Color.green)
            .frame(width: 150, height: 100);
    }
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        // Calculate total amount to pay from bill + tips
        let bill = Double(billAmountTextField.text!) ?? 0;
        let tip = bill * (Double(tipSlider.value) / 100);
        let total = bill + tip;
        
        // Update labels accordingly
        tipAmountLabel.text = String(format: "$%.2f", tip);
        totalLabel.text = String(format: "$%.2f", total);
    }

    @IBAction func sliderValueChanged(_ sender: UISlider) {
        // Change step count
        let step: Float = 1;
        let roundedValue = round(sender.value / step) * step;
        sender.value = roundedValue;
        
        // Calculate total amount to pay from bill + tips
        let bill = Double(billAmountTextField.text!) ?? 0;
        let tip = bill * Double(tipSlider.value) / 100;
        let total = bill + tip;
        
        // Update labels accordingly
        tipPercentageLabel.text = String(Int(sender.value)) + "%";
        tipAmountLabel.text = String(format: "$%.2f", tip);
        totalLabel.text = String(format: "$%.2f", total);
    }
}

